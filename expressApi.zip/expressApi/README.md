# expressApi

A sample API and Website.

## Notes

- You must change your connection string for the database.  The string included in this code contains fake data and you will not be able to connect with it.
