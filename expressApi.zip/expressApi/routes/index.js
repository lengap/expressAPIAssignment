var express = require('express');
var router = express.Router();
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var mongoose = require('mongoose');
var User = require('./users.js').User;
var Entry = require('./entries.js').Entry;
var validPassword = require('./users.js').validPassword;

passport.use(new LocalStrategy(
  function(username, password, done){ 
    User.findOne({username: username }, function(err, user){
      if(err) { console.log("Cant Connect"); return done(err); }
      if(!user) { console.log("Cant find User"); return done(null, false); }
      if(!validPassword(password, user.salt, user.password)){ console.log("Incorrect Password"); return done(null, false); }
      return done(null, user);
    }
   )
 }));

var checkAuthLocal = passport.authenticate('local', { failureRedirect: '/', session: true });

/* GET home page. */
router.get('/', function(req, res, next) {
    var name;
  if(req.user){
    var name = req.user.email;
  }
  res.render('index', { title: 'MyJournal - Data Collection Device', name: name });
});

router.get('/about', function(req, res, next){
  res.render('about', { title: 'About MyJournal'});
});

router.post('/login', checkAuthLocal, function(req, res, next){
  res.redirect('/');
});

router.get('/addUser', function(req, res, next){
	res.render('addUser');
});

router.get('/newNote', function(req, res, next){
	res.render('newNote');
})

router.get('/accountInfo', async function(req, res, next){
	if(!req.isAuthenticated()){
		res.redirect('/');
	} else {
		if(req.user.admin){
			var userInfo = await User.find({});
			res.render('accountInfo', { userInfo : userInfo } );
		}
		else
		{
			var userInfo = await User.find({ email : req.user.email });
			res.render('accountInfo', { userInfo : userInfo } );
		}
		
	}
});

router.get('/viewNote/:entryId', async function(req, res, next){
	if(!req.isAuthenticated()){
		res.redirect('/');
	} else {
		var entries = await Entry.find({ 
			userId : req.user._id,
			_id : req.params.entryId
		});
		res.render('viewNote', { entries : entries } );
	}
});

router.post('/editNote/:entryId', async function(req, res, next){
	if(!req.isAuthenticated()){
		res.redirect('/');
	}
	else
	{
		var entry = await Entry.findOne({
			userId : req.user._id,
			_id : req.params.entryId
		});

		if(!entry){
			var error = new Error('Entry not found.');
			error.status = 404;
			throw error;
		}

		if(!(req.body.entry && req.body.mood && req.body.date)){
			console.log(req.body);
			var error = new Error('Missing required information.');
			error.status = 400;
			throw error;
		}

		entry.entry = req.body.entry;
		entry.mood = req.body.mood;
		entry.date = req.body.date;
		entry.save();
		
		res.render('/');
	}
	
});

router.get('/logout', function(req, res){
	req.logout();
	res.redirect('/');
});

router.get('/journal', async function(req, res){
	if(!req.isAuthenticated()){
		res.redirect('/');
	} else {
		var entries = await Entry.find({ userId : req.user._id });
		res.render('journal', { entries : entries } );
	}
});

router.post('/deleteNote/:entryId', async function(req, res, next){
	if(!req.isAuthenticated()){
		res.redirect('/');
	} else {
		var entries = await Entry.deleteOne({ 
			userId : req.user._id,
			_id : req.params.entryId
		});
		res.redirect('/journal');
	}
});

module.exports = router;
